# Card Platform

Platform game kartu multiplayer (Remi Jenderal, UNO, Kartu Jitak Domino) — Next.js 15 + Supabase.

Status build ini: **Tahap 1 (Arsitektur) + Tahap 2 (Struktur Folder) + Tahap 3 sebagian (skema Auth/Profile) + Tahap 4 (Authentication) — SELESAI dan berfungsi penuh.**
Fitur lain (Lobby, Room, Realtime, Game Engine, Shop, dsb) akan ditambahkan bertahap sesuai roadmap di `01-system-architecture.md`.

## 1. Setup Supabase

1. Buat project baru di https://supabase.com
2. Buka **SQL Editor**, jalankan isi file `supabase/migrations/0001_init_auth_profiles.sql`
3. Buka **Authentication > Settings**:
   - Aktifkan **Email confirmations** (opsional, sesuai kebutuhan)
   - Set **Site URL** = URL Netlify Anda nanti (atau `http://localhost:3000` untuk dev)
4. Buka **Project Settings > API**, salin `Project URL`, `anon public key`, `service_role key`
5. Generate types asli (opsional tapi disarankan):
   ```bash
   npx supabase gen types typescript --project-id <project-id> > src/lib/supabase/database.types.ts
   ```

## 2. Setup Lokal

```bash
npm install
cp .env.example .env.local
# isi .env.local dengan kredensial Supabase Anda
npm run dev
```

Buka `http://localhost:3000` — akan redirect ke `/login`.

## 3. Deploy ke Netlify

1. Push project ini ke GitHub/GitLab
2. Di Netlify: **Add new site > Import an existing project**
3. Build command: `npm run build` (sudah di-set di `netlify.toml`)
4. Publish directory: `.next` (sudah di-set di `netlify.toml`)
5. Plugin `@netlify/plugin-nextjs` sudah terdaftar di `netlify.toml` — Netlify akan otomatis meng-handle SSR, Server Actions, dan Route Handler edge runtime
6. Tambahkan Environment Variables di Netlify Dashboard (Site settings > Environment variables):
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `NEXT_PUBLIC_SITE_URL` → isi dengan URL Netlify Anda setelah deploy pertama (mis. `https://card-platform.netlify.app`)
7. Deploy. Setelah URL Netlify jadi, update juga **Site URL** & **Redirect URLs** di Supabase Auth Settings agar email verifikasi/reset password mengarah ke domain yang benar.

## 4. Struktur Folder (Feature-Based Architecture)

```
app/                        → routing Next.js App Router saja (tipis, tanpa logic bisnis)
  (auth)/                   → route group: login, register, forgot-password, reset-password
  (main)/                   → route group: lobby, room, profile (butuh login)
src/
  lib/supabase/             → 3 client Supabase: browser, server, middleware
  components/ui/            → komponen UI generik (Button, FormField, GlassCard, dst)
  stores/                   → Zustand store (client-side ephemeral state)
  features/
    auth/                   → schemas, actions, services, components milik fitur auth
    profile/ friends/ room/ lobby/ leaderboard/ notification/
    shop/ report/ moderation/  → skeleton siap diisi tahap berikutnya
    games/
      core/                 → GameEngine interface bersama
      remi/ uno/ domino/    → engine per game (diisi di Tahap 8)
supabase/
  migrations/                → SQL migration, sumber kebenaran skema DB
```

**Aturan penting:** setiap fitur di `src/features/*` HANYA boleh diakses lewat file
`index.ts` (public API-nya sendiri) oleh fitur lain — jangan import langsung
`internal` file fitur lain untuk menjaga boundary modular.

## 5. Keamanan yang Sudah Diterapkan di Tahap Ini

- Row Level Security aktif di semua tabel (`profiles`, `player_statistics`, `audit_logs`)
- Kolom privileged (`role`, `coin`, `exp`, `mmr`, `verified_badge`, status ban/suspend)
- Kolom privileged (`role`, `coin`, `exp`, `mmr`, `verified_badge`, status ban/suspend) dikunci oleh trigger `protect_privileged_columns` — hanya bisa diubah lewat RPC resmi (akan ditambahkan di tahap Moderation & Economy)
- Cek status **ban/suspend saat login**, ditampilkan langsung ke user sesuai requirement
- Password policy: minimal 8 karakter, wajib huruf besar + angka (client & server validation via Zod yang sama)
- `forgotPasswordAction` selalu me-return sukses generik untuk mencegah email enumeration

## Roadmap Selanjutnya

- Tahap 5: Lobby (daftar game, room aktif, player online, leaderboard, announcement)
- Tahap 6: Room (create/join, password, public/private, 2-4 pemain)
- Tahap 7: Realtime (Postgres Changes + Presence + Broadcast per room)
- Tahap 8: Game Engine (Remi Jenderal, UNO, Kartu Jitak Domino)
- Tahap 9-10: UI lanjutan & fitur tersisa (friends, chat, shop, moderation, dashboard, dsb) satu per satu
