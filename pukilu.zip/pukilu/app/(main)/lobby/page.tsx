import { getCurrentProfile } from "@/features/auth/services/auth.service";
import { GlassCard } from "@/components/ui/GlassCard";

export default async function LobbyPage() {
  const profile = await getCurrentProfile();

  return (
    <div className="mx-auto max-w-5xl p-6">
      <GlassCard className="p-6">
        <h1 className="text-2xl font-bold">Selamat datang, {profile?.display_name} 👋</h1>
        <p className="mt-2 text-white/50">
          Ini halaman Lobby placeholder. Fitur room, daftar game, leaderboard,
          dan chat akan diimplementasikan di Tahap 5 sesuai urutan kerja.
        </p>
      </GlassCard>
    </div>
  );
}
