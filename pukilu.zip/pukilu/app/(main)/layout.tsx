import { getCurrentProfile } from "@/features/auth/services/auth.service";
import { redirect } from "next/navigation";
import { logoutAction } from "@/features/auth/actions/auth.actions";
import { Button } from "@/components/ui/Button";

export default async function MainLayout({ children }: { children: React.ReactNode }) {
  const profile = await getCurrentProfile();
  if (!profile) redirect("/login");

  return (
    <div className="min-h-screen">
      <header className="flex items-center justify-between border-b border-white/10 bg-black/20 px-6 py-3 backdrop-blur-xl">
        <span className="bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text font-bold text-transparent">
          Card Platform
        </span>
        <div className="flex items-center gap-4">
          <span className="text-sm text-white/70">
            {profile.display_name}{" "}
            <span className="text-white/40">· {profile.coin} coin</span>
          </span>
          <form action={logoutAction}>
            <Button variant="ghost" type="submit" className="!px-3 !py-1.5 text-xs">
              Keluar
            </Button>
          </form>
        </div>
      </header>
      <main>{children}</main>
    </div>
  );
}
