import { redirect } from "next/navigation";
import { getCurrentProfile } from "@/features/auth/services/auth.service";

export default async function RootPage() {
  const profile = await getCurrentProfile();
  redirect(profile ? "/lobby" : "/login");
}
