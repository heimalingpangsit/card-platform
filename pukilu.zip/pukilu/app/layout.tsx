import type { Metadata } from "next";
import { Toaster } from "sonner";
import "@/app/globals.css";

export const metadata: Metadata = {
  title: {
    default: "Card Platform",
    template: "%s | Card Platform",
  },
  description: "Platform game kartu multiplayer — Remi Jenderal, UNO, Kartu Jitak Domino",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id" className="dark">
      <body className="min-h-screen bg-aurora antialiased">
        {children}
        <Toaster theme="dark" position="top-center" richColors />
      </body>
    </html>
  );
}
