import { ResetPasswordForm } from "@/features/auth/components/ResetPasswordForm";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Reset Password" };

export default function ResetPasswordPage() {
  return (
    <div>
      <h2 className="mb-6 text-xl font-semibold text-white">Atur Password Baru</h2>
      <ResetPasswordForm />
    </div>
  );
}
