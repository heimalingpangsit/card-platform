import { RegisterForm } from "@/features/auth/components/RegisterForm";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Daftar" };

export default function RegisterPage() {
  return (
    <div>
      <h2 className="mb-6 text-xl font-semibold text-white">Buat Akun Baru</h2>
      <RegisterForm />
    </div>
  );
}
