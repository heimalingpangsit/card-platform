import { GlassCard } from "@/components/ui/GlassCard";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-3xl font-bold text-transparent">
            Card Platform
          </h1>
          <p className="mt-1 text-sm text-white/40">
            Remi Jenderal · UNO · Kartu Jitak Domino
          </p>
        </div>
        <GlassCard className="p-8">{children}</GlassCard>
      </div>
    </div>
  );
}
