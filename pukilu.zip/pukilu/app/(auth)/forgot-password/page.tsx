import { ForgotPasswordForm } from "@/features/auth/components/ForgotPasswordForm";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Lupa Password" };

export default function ForgotPasswordPage() {
  return (
    <div>
      <h2 className="mb-6 text-xl font-semibold text-white">Lupa Password</h2>
      <ForgotPasswordForm />
    </div>
  );
}
