import { LoginForm } from "@/features/auth/components/LoginForm";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Masuk" };

export default function LoginPage() {
  return (
    <div>
      <h2 className="mb-6 text-xl font-semibold text-white">Masuk ke Akun</h2>
      <LoginForm />
    </div>
  );
}
