import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          violet: "#8b5cf6",
          fuchsia: "#d946ef",
        },
      },
    },
  },
  plugins: [],
};

export default config;
