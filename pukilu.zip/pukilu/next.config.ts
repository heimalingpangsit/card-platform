import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [
      {
        protocol: "https",
        // Ganti dengan hostname project Supabase Anda, mis: xxxx.supabase.co
        hostname: "*.supabase.co",
        pathname: "/storage/v1/object/public/**",
      },
    ],
  },
  experimental: {
    // Server Actions dipakai untuk mutasi (auth, room, dsb)
    serverActions: {
      bodySizeLimit: "2mb",
    },
  },
};

export default nextConfig;
