-- ============================================================================
-- Migration 0001: Auth & Profiles Foundation
-- ============================================================================

-- Enum untuk role platform (Owner / Admin / Player)
create type public.user_role as enum ('owner', 'admin', 'player');

-- Enum untuk rank MMR
create type public.rank_tier as enum (
  'rookie', 'bronze', 'silver', 'gold', 'platinum',
  'diamond', 'master', 'grandmaster', 'legend'
);

-- ============================================================================
-- TABLE: profiles
-- Satu baris per user, 1:1 dengan auth.users via FK id.
-- ============================================================================
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  display_name text not null,
  bio text default '',
  avatar_url text,
  banner_url text,
  avatar_frame_id uuid,
  avatar_decoration_id uuid,

  coin bigint not null default 0 check (coin >= 0),
  exp bigint not null default 0 check (exp >= 0),
  level integer not null default 1 check (level >= 1),
  mmr integer not null default 1000,
  rank_tier public.rank_tier not null default 'rookie',

  role public.user_role not null default 'player',
  verified_badge boolean not null default false,

  is_banned boolean not null default false,
  ban_reason text,
  banned_by uuid references public.profiles(id),
  banned_at timestamptz,

  is_suspended boolean not null default false,
  suspend_reason text,
  suspend_started_at timestamptz,
  suspend_ends_at timestamptz,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint username_format check (username ~ '^[a-zA-Z0-9_]{3,20}$')
);

create index idx_profiles_username on public.profiles (username);
create index idx_profiles_mmr on public.profiles (mmr desc);
create index idx_profiles_role on public.profiles (role);

-- ============================================================================
-- TABLE: player_statistics
-- Dipisah dari profiles agar tabel profile tetap ringan untuk query umum.
-- ============================================================================
create table public.player_statistics (
  profile_id uuid primary key references public.profiles(id) on delete cascade,
  total_matches integer not null default 0,
  total_wins integer not null default 0,
  total_losses integer not null default 0,
  win_streak integer not null default 0,
  best_win_streak integer not null default 0,
  updated_at timestamptz not null default now()
);

-- ============================================================================
-- FUNCTION + TRIGGER: auto-create profile saat user baru register
-- ============================================================================
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  base_username text;
  final_username text;
  suffix int := 0;
begin
  base_username := lower(regexp_replace(split_part(new.email, '@', 1), '[^a-zA-Z0-9_]', '', 'g'));
  if base_username = '' or base_username is null then
    base_username := 'player';
  end if;
  final_username := base_username;

  -- Pastikan username unik, tambahkan suffix angka jika bentrok
  while exists (select 1 from public.profiles where username = final_username) loop
    suffix := suffix + 1;
    final_username := base_username || suffix::text;
  end loop;

  insert into public.profiles (id, username, display_name)
  values (new.id, final_username, coalesce(new.raw_user_meta_data->>'display_name', base_username));

  insert into public.player_statistics (profile_id) values (new.id);

  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================================
-- FUNCTION: auto-update updated_at
-- ============================================================================
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger trg_profiles_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================
alter table public.profiles enable row level security;
alter table public.player_statistics enable row level security;

-- Siapa saja yang login boleh melihat profile publik siapa pun
-- (lobby, leaderboard, chat perlu ini)
create policy "profiles_select_all_authenticated"
  on public.profiles for select
  to authenticated
  using (true);

-- User hanya boleh update baris miliknya sendiri
create policy "profiles_update_own"
  on public.profiles for update
  to authenticated
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- Kolom sensitif (role, coin, exp, mmr, verified_badge, ban/suspend)
-- TIDAK BOLEH diubah lewat policy update biasa. Trigger di bawah ini
-- membatalkan perubahan pada kolom tsb kecuali dilakukan lewat RPC
-- SECURITY DEFINER (yang dijalankan atas nama sistem/admin, lihat migration
-- lanjutan untuk moderation & economy).
create or replace function public.protect_privileged_columns()
returns trigger language plpgsql as $$
begin
  if current_setting('request.jwt.claims', true) is not null then
    -- Request datang dari client biasa (bukan service role) -> kunci kolom privileged
    if new.role is distinct from old.role
      or new.coin is distinct from old.coin
      or new.exp is distinct from old.exp
      or new.mmr is distinct from old.mmr
      or new.rank_tier is distinct from old.rank_tier
      or new.verified_badge is distinct from old.verified_badge
      or new.is_banned is distinct from old.is_banned
      or new.is_suspended is distinct from old.is_suspended
    then
      raise exception 'Kolom ini hanya bisa diubah melalui RPC resmi, tidak lewat update langsung.';
    end if;
  end if;
  return new;
end;
$$;

create trigger trg_protect_privileged_columns
  before update on public.profiles
  for each row execute function public.protect_privileged_columns();

-- player_statistics hanya bisa dibaca, ditulis lewat RPC match settlement
create policy "player_statistics_select_all_authenticated"
  on public.player_statistics for select
  to authenticated
  using (true);

-- ============================================================================
-- TABLE: audit_logs (immutable dari sisi Admin — insert only, tidak ada delete/update policy)
-- ============================================================================
create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id),
  action text not null,
  target_type text not null,
  target_id text,
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.audit_logs enable row level security;

create policy "audit_logs_select_admin_owner"
  on public.audit_logs for select
  to authenticated
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role in ('admin', 'owner')
    )
  );

-- Tidak ada policy insert untuk role authenticated biasa —
-- insert hanya lewat RPC SECURITY DEFINER (service role context).
