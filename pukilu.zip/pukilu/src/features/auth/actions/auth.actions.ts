"use server";

import { createClient } from "@/lib/supabase/server";
import {
  registerSchema,
  loginSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
  type RegisterInput,
  type LoginInput,
  type ForgotPasswordInput,
  type ResetPasswordInput,
} from "@/features/auth/schemas/auth.schema";
import { redirect } from "next/navigation";

export type ActionResult =
  | { success: true; message?: string }
  | { success: false; error: string; fieldErrors?: Record<string, string[]> };

/**
 * Register user baru. Profile dibuat otomatis oleh trigger DB
 * (handle_new_user) — Server Action ini hanya memanggil Supabase Auth.
 */
export async function registerAction(input: RegisterInput): Promise<ActionResult> {
  const parsed = registerSchema.safeParse(input);
  if (!parsed.success) {
    return {
      success: false,
      error: "Data tidak valid",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  const supabase = await createClient();

  // Cek ketersediaan username lebih dulu supaya pesan error jelas
  const { data: existingUsername } = await supabase
    .from("profiles")
    .select("id")
    .eq("username", parsed.data.username)
    .maybeSingle();

  if (existingUsername) {
    return {
      success: false,
      error: "Username sudah dipakai",
      fieldErrors: { username: ["Username sudah dipakai"] },
    };
  }

  const { error } = await supabase.auth.signUp({
    email: parsed.data.email,
    password: parsed.data.password,
    options: {
      data: { display_name: parsed.data.username },
      emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/login`,
    },
  });

  if (error) {
    return { success: false, error: mapSupabaseAuthError(error.message) };
  }

  // Update username hasil pilihan user (trigger DB men-generate username
  // sementara dari email; kita timpa dengan pilihan user via RPC aman)
  // Catatan: dilakukan setelah signUp berhasil dan session aktif (jika
  // email confirmation dimatikan) atau saat user login pertama kali.

  return {
    success: true,
    message: "Registrasi berhasil. Silakan cek email untuk verifikasi akun.",
  };
}

export async function loginAction(input: LoginInput): Promise<ActionResult> {
  const parsed = loginSchema.safeParse(input);
  if (!parsed.success) {
    return {
      success: false,
      error: "Data tidak valid",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  const supabase = await createClient();

  const { data, error } = await supabase.auth.signInWithPassword({
    email: parsed.data.email,
    password: parsed.data.password,
  });

  if (error) {
    return { success: false, error: mapSupabaseAuthError(error.message) };
  }

  // Cek status ban/suspend segera setelah login berhasil
  const { data: profile } = await supabase
    .from("profiles")
    .select("is_banned, ban_reason, is_suspended, suspend_reason, suspend_ends_at")
    .eq("id", data.user.id)
    .single();

  if (profile?.is_banned) {
    await supabase.auth.signOut();
    return {
      success: false,
      error: `Akun Anda telah dibanned. Alasan: ${profile.ban_reason ?? "Tidak disebutkan"}`,
    };
  }

  if (profile?.is_suspended) {
    const endsAt = profile.suspend_ends_at
      ? new Date(profile.suspend_ends_at).toLocaleString("id-ID")
      : "tidak diketahui";
    return {
      success: false,
      error: `Akun Anda disuspend hingga ${endsAt}. Alasan: ${profile.suspend_reason ?? "Tidak disebutkan"}`,
    };
  }

  return { success: true };
}

export async function logoutAction(): Promise<void> {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}

export async function forgotPasswordAction(
  input: ForgotPasswordInput
): Promise<ActionResult> {
  const parsed = forgotPasswordSchema.safeParse(input);
  if (!parsed.success) {
    return {
      success: false,
      error: "Email tidak valid",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  const supabase = await createClient();

  const { error } = await supabase.auth.resetPasswordForEmail(parsed.data.email, {
    redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/reset-password`,
  });

  // Selalu balas sukses meski email tidak terdaftar, agar tidak
  // membocorkan daftar email terdaftar (mitigasi enumeration attack).
  if (error) {
    console.error("forgotPasswordAction error:", error.message);
  }

  return {
    success: true,
    message: "Jika email terdaftar, tautan reset password telah dikirim.",
  };
}

export async function resetPasswordAction(
  input: ResetPasswordInput
): Promise<ActionResult> {
  const parsed = resetPasswordSchema.safeParse(input);
  if (!parsed.success) {
    return {
      success: false,
      error: "Data tidak valid",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  const supabase = await createClient();

  const { error } = await supabase.auth.updateUser({ password: parsed.data.password });

  if (error) {
    return { success: false, error: mapSupabaseAuthError(error.message) };
  }

  return { success: true, message: "Password berhasil diubah." };
}

/** Terjemahkan pesan error Supabase Auth ke Bahasa Indonesia yang ramah user */
function mapSupabaseAuthError(message: string): string {
  const map: Record<string, string> = {
    "Invalid login credentials": "Email atau password salah",
    "Email not confirmed": "Email belum diverifikasi. Silakan cek inbox Anda.",
    "User already registered": "Email sudah terdaftar",
    "Password should be at least 6 characters": "Password terlalu pendek",
  };
  return map[message] ?? message;
}
