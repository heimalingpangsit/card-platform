"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  forgotPasswordSchema,
  type ForgotPasswordInput,
} from "@/features/auth/schemas/auth.schema";
import { forgotPasswordAction } from "@/features/auth/actions/auth.actions";
import { FormField } from "@/components/ui/FormField";
import { Button } from "@/components/ui/Button";
import { motion } from "framer-motion";
import { toast } from "sonner";
import Link from "next/link";
import { useState } from "react";
import { CheckCircle2 } from "lucide-react";

export function ForgotPasswordForm() {
  const [sent, setSent] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ForgotPasswordInput>({
    resolver: zodResolver(forgotPasswordSchema),
  });

  async function onSubmit(data: ForgotPasswordInput) {
    const result = await forgotPasswordAction(data);
    if (!result.success) {
      toast.error(result.error);
      return;
    }
    setSent(true);
    toast.success(result.message ?? "Email terkirim");
  }

  if (sent) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center gap-3 py-4 text-center"
      >
        <CheckCircle2 className="h-12 w-12 text-emerald-400" />
        <p className="text-white/80">
          Jika email terdaftar, tautan reset password sudah dikirim. Cek inbox
          (dan folder spam) Anda.
        </p>
        <Link href="/login" className="text-sm text-violet-300 hover:underline">
          Kembali ke halaman masuk
        </Link>
      </motion.div>
    );
  }

  return (
    <motion.form
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      onSubmit={handleSubmit(onSubmit)}
      className="flex flex-col gap-4"
    >
      <p className="text-sm text-white/50">
        Masukkan email akun Anda, kami akan mengirimkan tautan untuk reset password.
      </p>
      <FormField
        label="Email"
        type="email"
        placeholder="nama@email.com"
        error={errors.email?.message}
        {...register("email")}
      />
      <Button type="submit" isLoading={isSubmitting} className="mt-2 w-full">
        Kirim Tautan Reset
      </Button>
      <p className="text-center text-sm text-white/50">
        <Link href="/login" className="text-violet-300 hover:text-violet-200 hover:underline">
          Kembali ke halaman masuk
        </Link>
      </p>
    </motion.form>
  );
}
