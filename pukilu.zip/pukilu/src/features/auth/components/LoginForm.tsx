"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema, type LoginInput } from "@/features/auth/schemas/auth.schema";
import { loginAction } from "@/features/auth/actions/auth.actions";
import { FormField } from "@/components/ui/FormField";
import { Button } from "@/components/ui/Button";
import { motion } from "framer-motion";
import { toast } from "sonner";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";

export function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
  });

  async function onSubmit(data: LoginInput) {
    setServerError(null);
    const result = await loginAction(data);

    if (!result.success) {
      setServerError(result.error);
      toast.error(result.error);
      return;
    }

    toast.success("Berhasil masuk!");
    const redirectTo = searchParams.get("redirectTo") ?? "/lobby";
    router.push(redirectTo);
    router.refresh();
  }

  return (
    <motion.form
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      onSubmit={handleSubmit(onSubmit)}
      className="flex flex-col gap-4"
    >
      <FormField
        label="Email"
        type="email"
        placeholder="nama@email.com"
        error={errors.email?.message}
        {...register("email")}
      />
      <FormField
        label="Password"
        type="password"
        placeholder="••••••••"
        error={errors.password?.message}
        {...register("password")}
      />

      {serverError && (
        <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">
          {serverError}
        </p>
      )}

      <div className="flex justify-end">
        <Link
          href="/forgot-password"
          className="text-sm text-violet-300 hover:text-violet-200 hover:underline"
        >
          Lupa password?
        </Link>
      </div>

      <Button type="submit" isLoading={isSubmitting} className="mt-2 w-full">
        Masuk
      </Button>

      <p className="text-center text-sm text-white/50">
        Belum punya akun?{" "}
        <Link href="/register" className="text-violet-300 hover:text-violet-200 hover:underline">
          Daftar sekarang
        </Link>
      </p>
    </motion.form>
  );
}
